import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../_services';

@Component({
  templateUrl: './current-training.component.html',
  styleUrls: ['./current-training.component.css']
})
export class CurrentTrainingComponent implements OnInit {
  ngOnInit() {}

}
