import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'notification-section',
  templateUrl: './notification.component.html',
  styleUrls: ['./notification.component.css']
})
export class NotificationComponent implements OnInit {

  ngOnInit(){}

}