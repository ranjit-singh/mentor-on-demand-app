export class Mentor {
    id: string;
    mentorName: string;
    experience: number;
    technologySpecialist: string;
    feeCharge: number;
    rating: number;
    noOfTraining: number;
}
