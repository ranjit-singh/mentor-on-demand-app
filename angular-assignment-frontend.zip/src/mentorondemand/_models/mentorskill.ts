export class MentorSkill {
    id: string;
    mId: string;
    sId: string;
    selfRating: string;
    yearsOfExp: number;
    trainingsDelivered: string;
    facilitiesOffered: string;
}
